When you start the app and find you need help with understanding it, read the first tab, the green text and do what it says.

It is a god idea to keep the database faile that end with ".csv" updated once a month if using this program, information on ubtaining an updated version is in the "databases.txt" file.